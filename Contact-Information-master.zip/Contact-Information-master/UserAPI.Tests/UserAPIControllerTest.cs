﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Angular2MVC.Controllers;

namespace UserAPI.Tests
{
    [TestClass]
    public class UserAPIControllerTest
    {
        [TestMethod]
        public void GetUsers_ShouldReturnOK()
        {
            // Arrange
             

            // Act

            // Assert
        }
    }
}
