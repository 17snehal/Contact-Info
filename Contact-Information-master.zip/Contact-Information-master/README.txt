Contact-Information
"Contact Information" is created to demonstrate get/add/edit/delete of contacts.

Steps to run this project:
1. Download Angular2MVC folder which has actual project.
2. Open .csproj in visual studio 2015/17.
3. Restore packages, right click on package.json, click on Restore Packages else navigate to package.json location via CMD and run command "npm install"
4. Try to Build solution in VS2015/17. If package dependency error occurs, just delete package folder and re-build.
5. On successful build, hit cntl+F5 to launch the web portal
6. Click on 'Contact-Information' to navigate.
7. Validations in place: 
	a. Required field 
	b. Minimum length for input controls 
	c. Email validation 
	d. Phone number validation
	
